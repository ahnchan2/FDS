import sys
import os
import json
import cv2.cv2 as cv2
import numpy as np
import time


def main():
    # img_dir = r'E:\Jongchan\homework\tmp\01_textinthewild_book_images'
    # img_dir = r'E:\Jongchan\homework\tmp\01_textinthewild_goods_images'
    # img_dir = r'E:\Jongchan\homework\tmp\01_textinthewild_signboard_images'
    img_dir = r'E:\Jongchan\homework\tmp\01_textinthewild_traffic_sign_images'

    info_file = r'E:\Jongchan\ai_hub\textinthewild_data_info.json'
    dataset = 'textinthewild'

    if dataset == 'printed':
        convert_printed_data(info_file, img_dir)
    elif dataset == 'textinthewild':
        convert_textinthewild_data(info_file, img_dir)
    elif dataset == 'handwriting':
        pass
    else:
        print("no dataset")
        return


def read_json(file):
    with open(file, encoding='utf-8') as fp:
        json_data = json.load(fp)
    return json_data


def convert_textinthewild_data(info_file, img_dir):
    # step1: get image list in img_dir
    img_list = os.listdir(img_dir)
    print("img_list count: {}".format(len(img_list)))

    # step2: read meta json
    tic = time.time()
    print("start read_json")
    meta_dict = read_json(info_file)
    print("end read_json, processing time: {:.2f} sec".format(time.time() - tic))

    images_cnt = len(meta_dict['images'])

    # step3: create labelme format by image_id & file_name
    image_id_dict = {}
    for i in range(images_cnt):
        if i % 10000 == 0:
            print("step3 current processing: {} / {}".format(i+1, images_cnt))
        images_dict = meta_dict['images'][i]
        if images_dict['file_name'] in img_list:
            image_id_dict[images_dict['id']] = {"flags": {},
                                                            "version": "4.2.9",
                                                            "imagePath": images_dict['file_name'],
                                                            "imageWidth": images_dict['width'],
                                                            "imageHeight": images_dict['height'],
                                                            "shapes": []
                                                            }
    print("img_list cnt: {}, image_id_dict cnt: {}".format(len(img_list), len(image_id_dict)))
    # assert len(img_list) == len(image_id_dict)

    # step4: create elements of labelme format
    for k, annotations_dict in enumerate(meta_dict['annotations']):
        if k % 100000 == 0:
            print("step4 current processing: {} / {}".format(k+1, len(meta_dict['annotations'])))
        if annotations_dict['image_id'] in image_id_dict.keys():
            points = get_points_by_bbox(img_dir, image_id_dict[annotations_dict['image_id']]['imagePath'], annotations_dict['bbox'])
            if points is None:
                continue
            shape = {"flags": {},
                        "group_id": None,
                        "label": "text",
                        # "label": annotations_dict['text'],
                        "shape_type": "polygon",
                        "points": points
                        }
            image_id_dict[annotations_dict['image_id']]['shapes'].append(shape)

    # step5: write labelme format file
    for n, (image_id, labelme_dict) in enumerate(image_id_dict.items()):
        if n % 100 == 0:
            print("step5 current processing: {} / {}".format(n+1, len(image_id_dict)))
        json_file_name = os.path.splitext(labelme_dict['imagePath'])[0] + '.json'
        json_file_path = os.path.join(img_dir, json_file_name)
        with open(json_file_path, 'w', encoding='utf-8') as fp:
            json.dump(labelme_dict, fp, ensure_ascii=False)


def get_points_by_bbox(dir, file, bbox):
    x_point_interval = 3
    y_point_interval = 3
    x1, y1, x2, y2 = bbox[0], bbox[1], bbox[0]+bbox[2], bbox[1]+bbox[3]

    bbox_w = abs(bbox[2])
    bbox_h = abs(bbox[3])

    debug = False
    if bbox[2] < 0 or bbox[3] < 0 or (bbox[0] > bbox[0] + bbox[2]) or (bbox[1] > bbox[1] + bbox[3]):
        print("except case")
        print("\t+ file: {}, bbox: {}".format(file, bbox))
        print("\t+ x1,y1,x2,y2: [{},{},{},{}], w,h: [{},{}]".format(x1, y1, x2, y2, bbox_w, bbox_h))
        debug = True
        # sys.exit(1)
    # assert bbox[2] > 0
    # assert bbox[3] > 0
    # assert bbox[0] < bbox[0] + bbox[2]
    # assert bbox[1] < bbox[1] + bbox[3]
    if debug:
        img = cv2.imread(os.path.join(dir, file))
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

    points = []
    x_points = np.linspace(x1, x2, num=int(bbox_w / x_point_interval))
    # print("x_points count: {}, x_points: {}".format(len(x_points), x_points))
    # if len(x_points) < 2:
    #     print("\t+ points: {}, file: {}, bbox: {}".format(None, file, bbox))
    #     img = cv2.imread(os.path.join(dir, file))
    #     cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    #     debug_dir = r'F:\data\convert\debug_small_bbox'
    #     cv2.imwrite(os.path.join(debug_dir, str(time.time()) + "_" + file), img)
    #     return None
    for x in x_points:
        points.append([int(x), y1])  # top-line points
        points.append([int(x), y2])  # bottom-line points
        if debug:
            cv2.circle(img, (int(x), y1), 5, (0, 0, 255), -1)
            cv2.circle(img, (int(x), y2), 5, (0, 0, 255), -1)

    y_points = np.linspace(y1, y2, num=int(bbox_h / y_point_interval))[1:-1]
    # print("y_points count: {}, y_points: {}".format(len(y_points), y_points))
    # if len(y_points) < 1:
    #     print("\t+ points: {}, file: {}, bbox: {}".format(None, file, bbox))
    #     img = cv2.imread(os.path.join(dir, file))
    #     cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    #     debug_dir = r'F:\data\convert\debug_small_bbox'
    #     cv2.imwrite(os.path.join(debug_dir, str(time.time()) + "_" + file), img)
    #     return None
    for y in y_points:
        points.append([x1, int(y)])  # left-line points
        points.append([x2, int(y)])  # right-line points
        if debug:
            cv2.circle(img, (x1, int(y)), 5, (0, 0, 255), -1)
            cv2.circle(img, (x2, int(y)), 5, (0, 0, 255), -1)

    # print("points count: {}, points: {}".format(len(points), points))
    # print("points count: {}".format(len(points)))

    if debug:
        debug_dir = r'E:\Jongchan\homework\tmp\debug_abnormal_point'
        cv2.imwrite(os.path.join(debug_dir, str(time.time()) + "_" + file), img)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
    if len(points) < 3:
        print("\t+ points: {}, file: {}, bbox: {}".format(None, file, bbox))
        img = cv2.imread(os.path.join(dir, file))
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        debug_dir = r'E:\Jongchan\homework\tmp\debug_small_bbox'
        cv2.imwrite(os.path.join(debug_dir, str(time.time()) + "_" + file), img)
        return None

    return points


def convert_printed_data(info_file, img_dir):
    # step1: get image list in img_dir
    img_list = os.listdir(img_dir)
    print("img_list count: {}".format(len(img_list)))

    # step2: get image info in info_dict by image list
    tic = time.time()
    print("start read_json")
    meta_dict = read_json(info_file)
    print("end read_json, processing time: {:.2f} sec".format(time.time() - tic))

    assert len(meta_dict['images']) == len(meta_dict['annotations'])

    data_cnt = len(meta_dict['images'])

    for i in range(data_cnt):
        if i % 10000 == 0:
            print("current index: {} / {}".format(i+1, data_cnt))
        images_dict = meta_dict['images'][i]
        annotations_dict = meta_dict['annotations'][i]

        assert images_dict['id'] == annotations_dict['image_id']

        # step3: check matched image info
        if images_dict['file_name'] in img_list:
            # step4: get points in image (segmentation)
            points = get_points_in_image(img_dir, images_dict['file_name'])

            # step5: create labelme format
            labelme_json = create_labelme_format(images_dict, annotations_dict, points)
            print("labelme_json: {}".format(labelme_json))

            # step6: write labelme format to file
            json_file_name = os.path.splitext(images_dict['file_name'])[0] + '.json'
            json_file_path = os.path.join(img_dir, json_file_name)
            with open(json_file_path, 'w', encoding='utf-8') as fp:
                json.dump(labelme_json, fp, ensure_ascii=False)

        if i == data_cnt - 1:
            print("complete: {} / {}".format(i+1, data_cnt))


def get_points_in_image(dir, file):
    img = cv2.imread(os.path.join(dir, file))
    print(img.shape)

    pad = 4
    point_interval = 10
    x1, y1 = pad, pad
    x2, y2 = img.shape[1]-pad, img.shape[0]-pad
    bbox_w = x2 - x1
    bbox_h = y2 - y1
    # print("x1,y1: [{},{}]".format(x1, y1))
    # print("x2,y2: [{},{}]".format(x2, y2))
    # print("bbox_w: {}, bbox_h: {}".format(bbox_w, bbox_h))
    cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

    assert bbox_w > point_interval
    assert bbox_h > point_interval

    points = []
    x_points = np.linspace(x1, x2, num=int(bbox_w / point_interval))
    # print("x_points count: {}, x_points: {}".format(len(x_points), x_points))
    for x in x_points:
        points.append([int(x), y1])  # top-line points
        points.append([int(x), y2])  # bottom-line points
        cv2.circle(img, (int(x), y1), 1, (0, 0, 255), -1)
        cv2.circle(img, (int(x), y2), 1, (0, 0, 255), -1)

    y_points = np.linspace(y1, y2, num=int(bbox_h / point_interval))[1:-1]
    # print("y_points count: {}, y_points: {}".format(len(y_points), y_points))
    for y in y_points:
        points.append([x1, int(y)])  # left-line points
        points.append([x2, int(y)])  # right-line points
        cv2.circle(img, (x1, int(y)), 1, (0, 0, 255), -1)
        cv2.circle(img, (x2, int(y)), 1, (0, 0, 255), -1)

    # print("points count: {}, points: {}".format(len(points), points))
    print("points count: {}".format(len(points)))

    """ for debug """
    # debug_dir = r'F:\data\convert\debug'
    # cv2.imwrite(os.path.join(debug_dir, file), img)
    # cv2.imshow('bbox', img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    return points


    # gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # ret, thr = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
    # cv2.imshow('thr', thr)
    # cv2.waitKey(0)
    # contours, _ = cv2.findContours(thr, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    # # contours, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #
    # cnt = contours[0]
    # # cnt = 30
    #
    #
    # eps1 = 0.01 + cv2.arcLength(cnt, True)
    # eps2 = 0.1 + cv2.arcLength(cnt, True)
    #
    # approx1 = cv2.approxPolyDP(cnt, eps1, True)
    # approx2 = cv2.approxPolyDP(cnt, eps2, True)
    #
    # img1 = img.copy()
    # img2 = img.copy()
    # img3 = img.copy()
    # img4 = img.copy()
    # cv2.drawContours(img1, [cnt], 0, (0, 255, 0), 1)
    # cv2.drawContours(img2, [approx1], 0, (255, 0, 0), 1)
    # cv2.drawContours(img3, [approx2], 0, (0, 0, 255), 1)
    #
    # hull = cv2.convexHull(cnt)
    # cv2.drawContours(img4, [hull], 0, (0, 0, 255), 1)
    # hull = cv2.convexHull(cnt, returnPoints=False)
    # defects = cv2.convexityDefects(cnt, hull)
    #
    # for i in range(defects.shape[0]):
    #     sp, ep, fp, dist = defects[i, 0]
    #     start = tuple(cnt[sp][0])
    #     end = tuple(cnt[ep][0])
    #     farthest = tuple(cnt[fp][0])
    #
    #     cv2.circle(img4, farthest, 5, (0, 255, 0), -1)
    #
    # # cv2.imshow('contour', img1)
    # cv2.imshow('approx1', img2)
    # cv2.imshow('approx2', img3)
    # cv2.imshow('defects', img4)
    #
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


def create_labelme_format(images, annotations, points):
    labelme = {}
    labelme['flags'] = {}
    labelme['version'] = "4.2.9"
    labelme['imagePath'] = images['file_name']
    labelme['imageWidth'] = images['width']
    labelme['imageHeight'] = images['height']
    # labelme['imageData'] = None

    # create shapes
    shapes = []
    shape = {}
    # shape = collections.OrderedDict()
    shape['flags'] = {}
    shape['group_id'] = None
    # shape['label'] = annotations['text']
    shape['label'] = "text"
    shape['shape_type'] = "polygon"
    shape['points'] = points
    shapes.append(shape)

    labelme['shapes'] = shapes

    return labelme


if __name__ == '__main__':
    tic = time.time()
    print("start main")
    main()
    print("end main, processing time: {:.2f} sec".format(time.time() - tic))