import sys
import os
from PIL import Image, ImageDraw, ImageFont


src = r"E:\Jongchan\homework\tmp\generate\bg_image\type1.png"
image = Image.open(src).convert("RGBA")
w, h = image.size
txt = Image.new('RGBA', (300, 100), (255,255,255))
# mask = Image.new('RGBA', image.size, (255,255,255,0))

font = ImageFont.truetype("impact.ttf", 25)
d = ImageDraw.Draw(txt)

d.text((0, 0), "This text should be 5% alpha", font=font)
# combined = Image.alpha_composite(image, txt)
image.paste(txt, (0, 0))

output_path = r"E:\Jongchan\homework\tmp\generate\text_image"
output_file_path = os.path.join(output_path, 'result3.png')
image.save(output_file_path)