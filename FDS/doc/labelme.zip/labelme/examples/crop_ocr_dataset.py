import sys
import os
import json
# import cv2.cv2 as cv2
import numpy as np
import time
import PIL.Image


def main():
    img_dir_list = [r'E:\Jongchan\homework\data\01_textinthewild_book_images',
                    r'E:\Jongchan\homework\data\01_textinthewild_goods_images',
                    r'E:\Jongchan\homework\data\01_textinthewild_signboard_images',
                    r'E:\Jongchan\homework\data\01_textinthewild_traffic_sign_images']
    # img_dir_list = [r'E:\Jongchan\homework\tmp\01_textinthewild_book_images',
    #                 r'E:\Jongchan\homework\tmp\01_textinthewild_goods_images']
    info_file = r'E:\Jongchan\homework\data\textinthewild_data_info.json'
    output_dir = r'E:\Jongchan\homework\tmp\result'

    # read meta json
    tic = time.time()
    print("start read_json")
    meta_dict = read_json(info_file)
    print("end read_json, processing time: {:.2f} sec".format(time.time() - tic))

    for img_dir in img_dir_list:
        crop_textinthewild_data(meta_dict, img_dir, output_dir)


def crop_textinthewild_data(meta_dict, img_dir, output_dir):
    # step1
    img_list = os.listdir(img_dir)
    print("img_list count: {}".format(len(img_list)))

    # step2
    image_id_dict = {}
    images_cnt = len(meta_dict['images'])
    for i in range(images_cnt):
        if i % 10000 == 0:
            print("step2 current processing: {} / {}".format(i+1, images_cnt))
        images_dict = meta_dict['images'][i]
        if images_dict['file_name'] in img_list:
            image_id_dict[images_dict['id']] = {"file_name": images_dict['file_name'],
                                                            "width": images_dict['width'],
                                                            "height": images_dict['height'],
                                                            "type": images_dict['type']
                                                            }
    print("img_list cnt: {}, image_id_dict cnt: {}".format(len(img_list), len(image_id_dict)))
    # assert len(img_list) == len(image_id_dict)

    # step3
    meta_list = []
    none_text_cnt = 0
    for k, annotations_dict in enumerate(meta_dict['annotations']):
        if k % 100000 == 0:
            print("step3 current processing: {} / {}".format(k+1, len(meta_dict['annotations'])))
        if annotations_dict['image_id'] in image_id_dict.keys():
            # get info
            file_name = image_id_dict[annotations_dict['image_id']]['file_name']
            category = image_id_dict[annotations_dict['image_id']]['type']
            bbox = annotations_dict['bbox']
            text = annotations_dict['text']
            if text is None:
                none_text_cnt += 1
                print(">>>>> warning: text is None, none_text_cnt: {}".format(none_text_cnt))
                continue
            annotation_id = annotations_dict['id']

            # create meta
            output_file_name = os.path.splitext(file_name)[0] + "_" + annotation_id
            output_file_ext = os.path.splitext(file_name)[-1]
            output_file = os.path.join("imgs", category, output_file_name+output_file_ext)
            meta = output_file + "\t" + text + "\n"

            # crop & save image
            img = PIL.Image.open(os.path.join(img_dir, file_name)).convert('RGB')
            pad_left = 0
            pad_top = 0
            pad_right = 0
            pad_bottom = 0
            crop_img = img.crop((bbox[0] - pad_left,
                                        bbox[1] - pad_top,
                                        bbox[0] + bbox[2] + pad_right,
                                        bbox[1] + bbox[3] + pad_bottom))
            os.makedirs(os.path.join(output_dir, "imgs", category), exist_ok=True)
            try:
                crop_img.save(os.path.join(output_dir, output_file))
            except Exception as e:
                print(e)
                continue
            meta_list.append(meta)

    #step4
    with open(os.path.join(output_dir, "wild_text_label.txt"), "a", encoding="utf-8") as f:
        f.writelines(meta_list)


def read_json(file):
    with open(file, encoding='utf-8') as fp:
        json_data = json.load(fp)
    return json_data


if __name__ == '__main__':
    tic = time.time()
    print("start main")
    main()
    print("end main, processing time: {:.2f} sec".format(time.time() - tic))
