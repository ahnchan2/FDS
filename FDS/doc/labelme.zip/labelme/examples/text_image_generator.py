import sys
import os
from PIL import ImageFont
from PIL import Image
from PIL import ImageDraw
import random
import time
import numpy as np
import cv2
import json


def int_to_string(x):
    return str(x).zfill(2)


def create_bg_image(tile_file, bg_img_size):
    tile_img = Image.open(tile_file)
    tile_w, tile_h = tile_img.size

    # Creates a new empty image, RGB mode
    bg_img = Image.new('RGB', bg_img_size)
    w, h = bg_img.size

    # Iterate through a grid, to place the background tile
    for i in range(0, w, tile_w):
        for j in range(0, h, tile_h):
            # Change brightness of the images, just to emphasise they are unique copies
            # bg = Image.eval(bg, lambda x: x+(i+j)/1000)

            # paste the image at location i, j:
            bg_img.paste(tile_img, (i, j))
    return bg_img


def get_points_by_bbox(bbox):
    x_point_interval = 10
    y_point_interval = 10
    x1, y1, x2, y2 = bbox[0], bbox[1], bbox[0]+bbox[2], bbox[1]+bbox[3]

    bbox_w = abs(bbox[2])
    bbox_h = abs(bbox[3])

    if bbox[2] < 0 or bbox[3] < 0 or (bbox[0] > bbox[0] + bbox[2]) or (bbox[1] > bbox[1] + bbox[3]):
        print("except case")
        # print("\t+ file: {}, bbox: {}".format(file, bbox))
        print("\t+ x1,y1,x2,y2: [{},{},{},{}], w,h: [{},{}]".format(x1, y1, x2, y2, bbox_w, bbox_h))

    points = []
    x_points = np.linspace(x1, x2, num=int(bbox_w / x_point_interval))
    for x in x_points:
        points.append([int(x), y1])  # top-line points
        points.append([int(x), y2])  # bottom-line points

    y_points = np.linspace(y1, y2, num=int(bbox_h / y_point_interval))[1:-1]
    for y in y_points:
        points.append([x1, int(y)])  # left-line points
        points.append([x2, int(y)])  # right-line points

    if len(points) < 3:
        # print("\t+ points: {}, file: {}, bbox: {}".format(None, file, bbox))
        return None

    return points


def create_text_image(bg_img, year_list, month_list, day_list, text_list, font_list, output_dir, sample_limit_cnt):
    debug = True
    if debug:
        os.makedirs(os.path.join(output_dir, "debug"), exist_ok=True)

    # font color
    black = (0, 0, 0)
    white = (255, 255, 255)

    font_size = 50
    sep = r". "

    for i in range(sample_limit_cnt):
        # create final text
        year = random.choice(year_list)
        month = random.choice(month_list)
        day = random.choice(day_list)
        text = random.choice(text_list)
        font = ImageFont.truetype(random.choice(font_list), font_size)
        final_text_list = [year, sep, month, sep, day, r'  ', text]

        # draw final text
        bg = bg_img.copy()
        draw = ImageDraw.Draw(bg)
        left = None
        width, height = bg_img.size
        filename = str(time.time())
        shelf_life_label_points_list = []
        text_label_points_list = []

        shapes = []
        for idx, final_text in enumerate(final_text_list):
            w, h = draw.textsize(final_text, font)
            top = (height - h) / 2
            if idx == 0:
                left = (width - w) / 7
            draw.text((left, top), final_text, fill=black, font=font)
            if idx in [0, 2, 4]:  # case: shelf_life
                # draw.rectangle([(left, top), (left+w, top+h)], outline="red")  # debug
                points = get_points_by_bbox((left, top, w, h))
                shelf_life_label_points_list.append(points)
                if points is None:
                    continue
                shape = {"flags": {},
                         "group_id": None,
                         "label": "shelf_life",
                         "shape_type": "polygon",
                         "points": points
                 }
                shapes.append(shape)
            elif idx in [6]:  # case: text
                # draw.rectangle([(left, top), (left + w, top + h)], outline="green")  # debug
                points = get_points_by_bbox((left, top, w, h))
                text_label_points_list.append(points)
                if points is None:
                    continue
                shape = {"flags": {},
                         "group_id": None,
                         "label": "text",
                         "shape_type": "polygon",
                         "points": points
                 }
                shapes.append(shape)
            left += w

        # save
        output_file = os.path.join(output_dir, filename+'.jpg')
        bg.save(output_file)
        bg.close()

        # create labelme json
        labelme_json = {"flags": {},
                                            "version": "4.2.9",
                                            "imagePath": filename+'.jpg',
                                            "imageWidth": width,
                                            "imageHeight": height,
                                            "shapes": shapes
                                            }
        json_file_name = filename+'.json'
        json_file_path = os.path.join(output_dir, json_file_name)
        with open(json_file_path, 'w', encoding='utf-8') as fp:
            json.dump(labelme_json, fp, ensure_ascii=False)

        # debug: draw points
        if debug:
            img = cv2.imread(output_file)
            for points in shelf_life_label_points_list:
                for x, y in points:
                    cv2.circle(img, (int(x), int(y)), 3, (0, 0, 255), -1)
            for points in text_label_points_list:
                for x, y in points:
                    cv2.circle(img, (int(x), int(y)), 3, (0, 255, 0), -1)
            cv2.imwrite(os.path.join(output_dir, "debug", filename + ".jpg"), img)


def main():
    # step1: set tile/date/text/font
    year_list = list(map(int_to_string, range(2020, 2031)))
    month_list = list(map(int_to_string, range(1, 13)))
    day_list = list(map(int_to_string, range(1, 32)))
    text_list = ['까지', '제조', '유통', '부터', '부터4', '까', '제', '시', '까지TJ', '까지TD', '까지F1M', '부터PM1', 'EXP', 'A8', 'F3', 'A', 'B', 'D', 'F', '까지 A8']
    font_list = [r'C:\Windows\Fonts\gulim.ttc',
                 r'C:\Windows\Fonts\batang.ttc',
                 r'C:\Windows\Fonts\HMKMRHD.TTF']
    tile_list = [r"E:\Jongchan\homework\tmp\generate\bg_tile\type_00.PNG",
                 r"E:\Jongchan\homework\tmp\generate\bg_tile\type_01.PNG",
                 r"E:\Jongchan\homework\tmp\generate\bg_tile\type_02.PNG"]

    # step2: create background image by tile image
    bg_img_size = (800, 150)
    bg_img_list = []
    for tile_file in tile_list:
        bg_img = create_bg_image(tile_file, bg_img_size)
        bg_img_list.append(bg_img)

    # step3: create text image
    output_dir = r"E:\Jongchan\homework\tmp\generate\text_image"
    os.makedirs(output_dir, exist_ok=True)
    sample_limit_cnt = 5000
    for idx, bg_img in enumerate(bg_img_list):
        create_text_image(bg_img, year_list, month_list, day_list, text_list, font_list, output_dir, sample_limit_cnt)


if __name__ == '__main__':
    main()
