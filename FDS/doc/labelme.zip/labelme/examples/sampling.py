import os, sys
from random import sample
import shutil

# input_dir = r'F:\data\01_printed_word_images'
input_dir = r'F:\data\01_textinthewild_goods_images'
output_dir = r'F:\data\convert\labelme'
sample_cnt = 500
use_except = True
except_dir = r'F:\data\convert\coco_textinthewild_5000\train2017\JPEGImages'


if os.path.exists(output_dir) is False:
    os.makedirs(output_dir, exist_ok=True)

img_list = os.listdir(input_dir)
if use_except:
    except_list = os.listdir(except_dir)
    img_list = list(set(img_list).difference(set(except_list)))

samples = sample(img_list, sample_cnt)

if os.path.exists(output_dir) is False:
    os.makedirs(output_dir)
for idx, sample in enumerate(samples):
    if idx % 100 == 0:
        print("current index: {} / {}".format(idx+1, len(samples)))
    src = os.path.join(input_dir, sample)
    dst = os.path.join(output_dir, sample)
    shutil.copyfile(src, dst)

    if idx == len(samples) - 1:
        print("complete: {} / {}".format(idx+1, len(samples)))
