#!/usr/bin/env python

import argparse
import glob
import json
import os
import os.path as osp
import sys
import uuid

import numpy as np
import PIL.Image

import labelme

try:
    import pycocotools.mask
except ImportError:
    print('Please install pycocotools:\n\n    pip install pycocotools\n')
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument('input_dir', help='input annotated directory')
    parser.add_argument('output_dir', help='output dataset directory')
    parser.add_argument('--pad_left', type=int, default=0)
    parser.add_argument('--pad_right', type=int, default=0)
    parser.add_argument('--pad_top', type=int, default=0)
    parser.add_argument('--pad_bottom', type=int, default=0)
    args = parser.parse_args()

    os.makedirs(osp.join(args.output_dir), exist_ok=True)

    label_files = glob.glob(osp.join(args.input_dir, '*.json'))
    buffer = []
    for image_id, label_file in enumerate(label_files):
        print(label_file)
        with open(label_file, encoding='utf-8') as f:
            label_data = json.load(f)

        img_file = osp.join(
            osp.dirname(label_file), label_data['imagePath']
        )
        origin_img = PIL.Image.open(img_file).convert('RGB')
        img = np.asarray(origin_img)

        masks = {}                                     # for area
        for shape in label_data['shapes']:
            points = shape['points']
            label = shape['label']
            group_id = shape.get('group_id')
            shape_type = shape.get('shape_type')
            mask = labelme.utils.shape_to_mask(
                img.shape[:2], points, shape_type
            )

            if group_id is None:
                group_id = uuid.uuid1()

            instance = (label, group_id)

            if instance in masks:
                masks[instance] = masks[instance] | mask
            else:
                masks[instance] = mask

        idx = 0
        for instance, mask in masks.items():
            if "\n" in instance[0]:
                print("\t+ There's a newline in text. skip")
                continue

            mask = np.asfortranarray(mask.astype(np.uint8))
            mask = pycocotools.mask.encode(mask)
            bbox = pycocotools.mask.toBbox(mask).flatten().tolist()
            # print("bbox: {}".format(bbox))

            # crop image
            crop_img = origin_img.crop((bbox[0]-args.pad_left,
                                                    bbox[1]-args.pad_top,
                                                    bbox[0]+bbox[2]+args.pad_right,
                                                    bbox[1]+bbox[3]+args.pad_bottom))
            # use crop image min pixel size size
            w, h = crop_img.size
            min_pixel_size = 20
            if w < min_pixel_size or h < min_pixel_size:
                print("\t+ crop image is too small, min_pixel_size: {}".format(min_pixel_size))
                continue

            crop_file_name = osp.splitext(osp.split(label_file)[-1])[0]+'_'+str(idx).zfill(2)+'.png'
            print("\t+ crop {}: {}".format(idx, crop_file_name))
            output_file = osp.join(args.output_dir, crop_file_name)



            crop_img.save(output_file)
            buffer.append(crop_file_name + "\t" + instance[0])
            idx += 1

    # write filename & text_label
    with open(os.path.join(args.output_dir, "meta.txt"), mode='wt', encoding='utf-8') as fp:
        fp.write('\n'.join(buffer))

if __name__ == '__main__':
    main()
