import shutil
import os


def move_files(src_dir):
    dst_dir = r'E:\Jongchan\homework\tmp\convert\labelme'
    # dst_dir = r'E:\Jongchan\homework\tmp\d'

    files = os.listdir(src_dir)
    total_file_cnt = len(files)
    print("move files count: {}".format(total_file_cnt))

    for idx, file in enumerate(files):
        if idx % 5000 == 0:
            print("currnet processing: {} / {}".format(idx+1, total_file_cnt))
        src = os.path.join(src_dir, file)
        try:
            shutil.move(src, dst_dir)
        except Exception as e:
            print(e)
            continue


src_dir_list = [r'E:\Jongchan\homework\tmp\01_textinthewild_goods_images',
                r'E:\Jongchan\homework\tmp\01_textinthewild_signboard_images',
                r'E:\Jongchan\homework\tmp\01_textinthewild_traffic_sign_images']
# src_dir_list = [r'E:\Jongchan\homework\tmp\a',
#                 r'E:\Jongchan\homework\tmp\b',
#                 r'E:\Jongchan\homework\tmp\c']
for src_dir in src_dir_list:
    move_files(src_dir)

