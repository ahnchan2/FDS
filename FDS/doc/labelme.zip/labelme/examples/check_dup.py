import sys
import os

img_root_dir = r"E:\Jongchan\homework\tmp"
img_dir_list = [r"01_textinthewild_book_images",
                r"01_textinthewild_goods_images",
                r"01_textinthewild_signboard_images",
                r"01_textinthewild_traffic_sign_images"]

books = os.listdir(os.path.join(img_root_dir, img_dir_list[0]))
goods = os.listdir(os.path.join(img_root_dir, img_dir_list[1]))
sign = os.listdir(os.path.join(img_root_dir, img_dir_list[2]))
traffic_sign = os.listdir(os.path.join(img_root_dir, img_dir_list[3]))

print("books: {} files".format(len(books)))
print("goods: {} files".format(len(goods)))
print("sign: {} files".format(len(sign)))
print("traffic_sign: {} files".format(len(traffic_sign)))

print(set(books) & set(goods))
print(len(set(books) & set(goods)))

print(set(books) & set(sign))
print(len(set(books) & set(sign)))

print(set(books) & set(traffic_sign))
print(len(set(books) & set(traffic_sign)))

print(set(goods) & set(sign))
print(len(set(goods) & set(sign)))

print(set(goods) & set(traffic_sign))
print(len(set(goods) & set(traffic_sign)))

print(set(sign) & set(traffic_sign))
print(len(set(sign) & set(traffic_sign)))

sys.exit(0)
