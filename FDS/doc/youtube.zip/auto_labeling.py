# -*- coding: utf-8 -*-
import sys
import os
import argparse
import time
import numpy as np
from multiprocessing import Process
import io, os, collections
from google.cloud import vision
from enum import Enum
from google.cloud.vision import types
from PIL import Image, ImageDraw
import json
"""
set enviroment variable (keyfile path)
GOOGLE_APPLICATION_CREDENTIALS=keyfile.json
"""


class FeatureType(Enum):
    PAGE = 1
    BLOCK = 2
    PARA = 3
    WORD = 4
    SYMBOL = 5


def main(args):
    print("args: {}".format(args))
    for img_dir in os.listdir(args.img_root_dir):
        auto_labeling(args.img_root_dir, img_dir, args.output_root_dir, worker_num=args.worker_num)
        # break
        print("\n")


def auto_labeling(img_root_dir, img_dir, output_root_dir, worker_num=2):
    # step1: get images
    images = [os.path.join(img_root_dir, img_dir, image) for image in os.listdir(os.path.join(img_root_dir, img_dir))]
    print("total images: {}".format(len(images)))
    if len(images) < 1:
        print("no images in directory")
        return

    # step2: make chunks
    chunks = np.array_split(images, worker_num)
    chunks = [chunk for chunk in chunks if chunk.size > 0]
    if worker_num > len(chunks):
        print("too many worker_num, modify worker_num: {} -> {}".format(worker_num, len(chunks)))
        worker_num = len(chunks)
    else:
        print("worker_num: {}".format(worker_num))
    assert len(chunks) == worker_num

    # step3: create process
    os.makedirs(os.path.join(output_root_dir, img_dir, 'single'), exist_ok=True)
    os.makedirs(os.path.join(output_root_dir, img_dir, 'multi'), exist_ok=True)
    worker_list = []
    for chunk in chunks:
        worker = Process(target=auto_labeling_by_google_api, args=[os.path.join(output_root_dir, img_dir), chunk])
        worker_list.append(worker)

    # step4: start process
    for worker in worker_list:
        worker.start()

    # step5: join process
    for worker in worker_list:
        worker.join()


def auto_labeling_by_google_api(output_dir, files):
    tic = time.time()
    pid = os.getpid()
    print("pid : {}, start auto_labeling_by_google_api".format(pid))

    debug = True
    detect_error_cnt = 0
    no_detect_cnt = 0
    for file in files:
        # step1: call google api
        """
        # case: use full_text_annotation
        # bounds, texts, language_codes = render_doc_text(file, fileout)
        # assert len(bounds) == len(texts)
        # assert len(bounds) == len(language_codes)
        # print("texts: {}".format(texts))
        # print("language_codes: {}".format(language_codes))
        """
        bounding_polys, texts = detect_text(file)
        if len(bounding_polys) != len(texts):
            print("pid : {}, detect text error, file: {}".format(pid, file))
            detect_error_cnt += 1
            continue
        elif len(bounding_polys) == 0 or len(texts) == 0:
            print("pid : {}, no detect text in image, file: {}".format(pid, file))
            no_detect_cnt += 1
            continue

        if debug:
            fileout = os.path.join(output_dir, os.path.split(file)[-1])

            image = Image.open(file)
            draw = ImageDraw.Draw(image)

            for bounding_poly in bounding_polys:
                draw.polygon([
                    bounding_poly[0][0], bounding_poly[0][1],
                    bounding_poly[1][0], bounding_poly[1][1],
                    bounding_poly[2][0], bounding_poly[2][1],
                    bounding_poly[3][0], bounding_poly[3][1]], None, 'blue')
            image.save(fileout)

        # step2: make labelme format
        labelme_dict_single = create_labelme_format(file, bounding_polys, texts)
        labelme_dict_multi = create_labelme_format(file, bounding_polys, texts, multi_classes=True)
        # print("labelme_dict: {}".format(labelme_dict))

        # step3: write labelme format file
        json_file_name = os.path.splitext(os.path.split(file)[-1])[0] + '.json'
        with open(os.path.join(output_dir, 'single', json_file_name), 'w', encoding='utf-8') as fp:
            json.dump(labelme_dict_single, fp, ensure_ascii=False)
        with open(os.path.join(output_dir, 'multi', json_file_name), 'w', encoding='utf-8') as fp:
            json.dump(labelme_dict_multi, fp, ensure_ascii=False)

        # break
    print("pid: {}, end auto_labeling_by_google_api, processing files count: {}, detect error: {}, no detect: {}, processing time: {:.2f} sec".format(pid, len(files), detect_error_cnt, no_detect_cnt, time.time()-tic))


def create_labelme_format(file, bounding_polys, texts, multi_classes=False):
    width, height = Image.open(file).size
    filename = os.path.split(file)[-1]
    labelme_dict = {"flags": {},
                        "version": "4.2.9",
                        "imagePath": filename,
                        "imageWidth": width,
                        "imageHeight": height,
                        "imageData": None,
                        "shapes": []
                        }
    for i in range(len(bounding_polys)):
        if multi_classes:
            label = texts[i]
        else:
            label = "text"
        shape = {"flags": {},
                 "group_id": None,
                 "label": label,
                 "shape_type": "polygon",
                 "points": bounding_polys[i]
                 }
        # print("shape: {}".format(shape))
        labelme_dict['shapes'].append(shape)
    return labelme_dict



def draw_boxes(image, bounds, color):
    """Draw a border around the image using the hints in the vector list."""
    draw = ImageDraw.Draw(image)

    for bound in bounds:
        draw.polygon([
            bound.vertices[0].x, bound.vertices[0].y,
            bound.vertices[1].x, bound.vertices[1].y,
            bound.vertices[2].x, bound.vertices[2].y,
            bound.vertices[3].x, bound.vertices[3].y], None, color)
    return image


def get_document_bounds(image_file, feature):
    """Returns document bounds given an image."""
    client = vision.ImageAnnotatorClient()

    block_bounds = []
    paragraph_bounds = []
    word_bounds = []
    symbol_bounds = []

    block_language_codes = []
    paragraph_language_codes = []
    word_language_codes = []
    symbol_language_codes = []

    with io.open(image_file, 'rb') as image_file:
        content = image_file.read()

    image = types.Image(content=content)

    response = client.document_text_detection(image=image)
    print("response: {}".format(response))
    document = response.full_text_annotation

    # Collect specified feature bounds by enumerating all document features
    block_text_list = []
    paragraph_text_list = []
    word_text_list = []
    symbol_text_list = []
    for page in document.pages:
        page_text = ""
        for block in page.blocks:
            block_text = ""
            for paragraph in block.paragraphs:
                paragraph_text = ""
                for word in paragraph.words:
                    word_text = ""
                    for symbol in word.symbols:
                        symbol_bounds.append(symbol.bounding_box)
                        symbol_language_codes.append(symbol.property.detected_languages[0].language_code)
                        symbol_text_list.append(symbol.text)
                        if symbol.property.detected_break.type == 0:
                            word_text += symbol.text
                        elif symbol.property.detected_break.type == 1:
                            word_text += symbol.text + " "
                        elif symbol.property.detected_break.type == 5:
                            word_text += symbol.text + "\n"
                        else:
                            word_text += symbol.text

                    word_bounds.append(word.bounding_box)
                    word_language_codes.append(word.property.detected_languages[0].language_code)
                    # word_text_list.append(word_text)
                    word_text_list.append(word_text[:-1])
                    paragraph_text += word_text

                paragraph_bounds.append(paragraph.bounding_box)
                paragraph_language_codes.append(paragraph.property.detected_languages[0].language_code)
                # paragraph_text_list.append(paragraph_text)
                paragraph_text_list.append(paragraph_text[:-1])
                block_text += paragraph_text

            block_bounds.append(block.bounding_box)
            block_language_codes.append(block.property)
            # block_language_codes.append(block.property.detected_languages[0].language_code)
            # block_text_list.append(block_text)
            block_text_list.append(block_text[:-1])
            page_text += block_text

    # The list `bounds` contains the coordinates of the bounding boxes.
    # print("symbol_text_list: {}".format(symbol_text_list))
    # print("word_text_list: {}".format(word_text_list))
    # print("paragraph_text_list: {}".format(paragraph_text_list))
    # print("block_text_list: {}".format(block_text_list))
    return block_bounds, paragraph_bounds, word_bounds, symbol_bounds, \
           block_text_list, paragraph_text_list, word_text_list, symbol_text_list, \
           block_language_codes, paragraph_language_codes, word_language_codes, symbol_language_codes


def render_doc_text(filein, fileout):
    block_bounds, paragraph_bounds, word_bounds, symbol_bounds, \
    block_text_list, paragraph_text_list, word_text_list, symbol_text_list, \
    block_language_codes, paragraph_language_codes, word_language_codes, symbol_language_codes = get_document_bounds(filein, FeatureType.BLOCK)

    # customizing return value (bounds / text_list / language_codes)
    bounds = block_bounds + paragraph_bounds + word_bounds + symbol_bounds
    texts = block_text_list + paragraph_text_list + word_text_list + symbol_text_list
    language_codes = block_language_codes + paragraph_language_codes + word_language_codes + symbol_language_codes

    if fileout != 0:
        image = Image.open(filein)
        draw_boxes(image, block_bounds, 'blue')
        # draw_boxes(image, paragraph_bounds, 'red')
        # draw_boxes(image, word_bounds, 'yellow')
        # draw_boxes(image, symbol_bounds, 'green')
        image.save(fileout)

    print("bounds: {}, texts: {}, anguage_codes: {}".format(len(bounds), len(texts), len(language_codes)))
    return bounds, texts, language_codes


def detect_text(path):
    """Detects text in the file."""
    client = vision.ImageAnnotatorClient()

    with io.open(path, 'rb') as image_file:
        content = image_file.read()

    image = vision.types.Image(content=content)

    response = client.text_detection(image=image)
    if response.error.message:
        raise Exception(
            '{}\nFor more info on error messages, check: '
            'https://cloud.google.com/apis/design/errors'.format(
                response.error.message))

    # print("response: {}".format(response))
    texts = response.text_annotations

    bounding_polys = []
    text_labels = []
    for text in texts:
        # print("description: {}".format(text.description))
        # print("locale: {}".format(text.locale))

        # vertices = (['({},{})'.format(vertex.x, vertex.y)
        #              for vertex in text.bounding_poly.vertices])
        vertices = [[vertex.x, vertex.y]
                     for vertex in text.bounding_poly.vertices]
        # print('bounds: {}\n'.format(','.join(vertices)))

        bounding_polys.append(vertices)
        text_labels.append(text.description)

    return bounding_polys, text_labels

def detect_text_for_google(path):
    client = vision.ImageAnnotatorClient()

    with io.open(path, 'rb') as image_file:
        content = image_file.read()

    image = vision.types.Image(content=content)

    return client, image


def ocr_for_google(client, image):
    response = client.text_detection(image=image)
    texts = response.text_annotations
    # print(texts[0].description)
    # text_list = [texts[0].description]
    text_list = []
    text_dict = collections.OrderedDict()
    count = 0
    for i in range(1, len(texts)):
        # print('\n"{}"'.format(text.description))
        # print('==============================================================================================')
        text = texts[i]
        word = text.description
        print('\n"{}"'.format(word))

        vertices = (['({},{})'.format(vertex.x, vertex.y)
                     for vertex in text.bounding_poly.vertices])
        print('bounds: {}'.format(','.join(vertices)))
        print("vertices : {} ".format(vertices))
        text_list.append(word)
        text_dict[count] = (word, vertices)
        count = count + 1

    # with open(text_file_path_name, 'w', encoding='UTF-8') as writer:
    #     for text_line in text_list:
    #         writer.write(text_line)
    #         writer.write('\n')
    return text_list, text_dict


def parse_arguments(argv):
    parser = argparse.ArgumentParser(description='auto_labeling')
    parser.add_argument('--img_root_dir')
    parser.add_argument('--output_root_dir')
    parser.add_argument('--worker_num', type=int)
    return parser.parse_args(argv)


if __name__ == '__main__':
    # sys.argv = ['auto_labeling.py',
    #             '--img_root_dir', r'data\frame',
    #             '--output_root_dir', r'data\labelme_format',
    #             '--worker_num', '4']
    args = parse_arguments(sys.argv[1:])
    tic = time.time()
    print("start main")
    main(args)
    print("end main, processing time: {:.2f} sec".format(time.time() - tic))