# -*- coding: utf-8 -*-
import sys
import os
import argparse
import time
import subprocess as sp
import shlex
import json


def main(args):
    print("args: {}".format(args))
    output_root_path = os.path.abspath(args.output_path)

    video_files = [os.path.join(args.video_dirs, video_file) for video_file in os.listdir(args.video_dirs)]

    for video_file in video_files:
        try:
            tic = time.time()
            print("video_file: {}".format(video_file))
            output_path = os.path.join(output_root_path, os.path.splitext(os.path.split(video_file)[-1])[0])
            print("output_path: {}".format(output_path))

            extract_frame_from_video_by_iframe(video_file, output_path)
            print("extract_frame_from_video_by_iframe complete. {:.2f} sec\n".format(time.time()-tic))
        except Exception as e:
            print(e)
            print("skip extracting frame\n")


def extract_frame_from_video_by_iframe(video_file, output_path):
    now = str(time.time())
    os.makedirs(output_path, exist_ok=True)
    ffmpeg_cmd = ['ffmpeg',
           '-i', video_file,
           '-qscale:v', '4',
           '-vf', "select='eq(pict_type,PICT_TYPE_I)'",
           '-vsync', 'vfr',
           '-f', 'image2',
           os.path.join(output_path, now+"_%05d.jpg")
    ]
    print("ffmpeg command: {}".format(ffmpeg_cmd))
    sp.check_output(ffmpeg_cmd).decode('utf-8')


def get_video_resolution(video_file):
    cmd = "ffprobe -v quiet -print_format json -show_streams"
    args = shlex.split(cmd)
    args.append(video_file)
    print(args)

    ffprobe_output = json.loads(sp.check_output(args).decode('utf-8'))

    width = ffprobe_output['streams'][0]['width']
    height = ffprobe_output['streams'][0]['height']
    return width, height


def parse_arguments(argv):
    parser = argparse.ArgumentParser(description='extract_frame')
    parser.add_argument('--video_dirs')
    parser.add_argument('--output_path', default='download', help='analysis target video file')
    return parser.parse_args(argv)


if __name__ == '__main__':
    # sys.argv = ['extract_frame.py',
    #             '--video_dirs', r'data\video',
    #             '--output_path', r'data\frame']
    args = parse_arguments(sys.argv[1:])
    tic = time.time()
    print("start main")
    main(args)
    print("end main, processing time: {:.2f} sec".format(time.time()-tic))
