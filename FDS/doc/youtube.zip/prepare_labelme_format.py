import sys
import os
import argparse
import time
import numpy as np
from multiprocessing import Process
import shutil


def main(args):
    print("args: {}".format(args))

    # step1: get directory list
    json_dirs = os.listdir(args.json_root_dir)
    img_dirs = os.listdir(args.img_root_dir)
    target_dirs = list(set(json_dirs) & set(img_dirs))
    print("target_dirs count: {}".format(len(target_dirs)))
    print("target_dirs: {}".format(target_dirs))
    if len(target_dirs) < 1:
        print("no target_directory")
        return

    # step2: make chunks
    worker_num = args.worker_num
    chunks = np.array_split(target_dirs, worker_num)
    chunks = [chunk for chunk in chunks if chunk.size > 0]
    if worker_num > len(chunks):
        print("too many worker_num, modify worker_num: {} -> {}".format(worker_num, len(chunks)))
        worker_num = len(chunks)
    else:
        print("worker_num: {}".format(worker_num))
    assert len(chunks) == worker_num

    # step3: create process
    os.makedirs(args.output_root_dir, exist_ok=True)
    worker_list = []
    for chunk in chunks:
        worker = Process(target=prepare_labelme_format, args=[args.json_root_dir, args.img_root_dir, args.output_root_dir, args.label_type, chunk])
        worker_list.append(worker)

    # step4: start process
    for worker in worker_list:
        worker.start()

    # step5: join process
    for worker in worker_list:
        worker.join()


def prepare_labelme_format(json_root_dir, img_root_dir, output_root_dir, label_type, target_dirs):
    tic = time.time()
    pid = os.getpid()
    print("pid: {}, start prepare_labelme_format".format(pid))

    # print("json_root_dir: {}".format(json_root_dir))
    # print("img_root_dir: {}".format(img_root_dir))
    # print("output_root_dir: {}".format(output_root_dir))
    # print("label_type: {}\n".format(label_type))
    print("pid: {}, target_dirs: {}".format(pid, target_dirs))

    for target in target_dirs:
        json_files = os.listdir(os.path.join(json_root_dir, target, label_type))
        for json_file in json_files:
            # copy json files
            src_json_file = os.path.join(json_root_dir, target, label_type, json_file)
            print("pid: {}, src_json_file: {}".format(pid, src_json_file))
            shutil.copy(src_json_file, output_root_dir)

            # copy images
            src_img_file = os.path.join(img_root_dir, target, os.path.splitext(json_file)[0] + '.jpg')
            shutil.copy(src_img_file, output_root_dir)

    print("pid: {}, end prepare_labelme_format, processing time: {:.2f} sec".format(pid, time.time()-tic))


def parse_arguments(argv):
    parser = argparse.ArgumentParser(description='auto_labeling')
    parser.add_argument('--json_root_dir')
    parser.add_argument('--img_root_dir')
    parser.add_argument('--output_root_dir')
    parser.add_argument('--worker_num', default=2, type=int)
    parser.add_argument('--label_type')
    return parser.parse_args(argv)


if __name__ == '__main__':
    sys.argv = ['prepare_labelme_format.py',
                '--json_root_dir', r'data\labelme_format_manual_checked',
                '--img_root_dir', r'data\frame',
                '--output_root_dir', r'data\prepared_labelme_format',
                '--worker_num', '4',
                '--label_type', 'single']
    args = parse_arguments(sys.argv[1:])
    tic = time.time()
    print("start main")
    main(args)
    print("end main, processing time: {:.2f} sec".format(time.time() - tic))