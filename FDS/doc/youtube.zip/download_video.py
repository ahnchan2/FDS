# -*- coding: utf-8 -*-
import sys
import os
import argparse
from pytube import YouTube
import time


def main(args):
    print("args: {}".format(args))
    output_path = os.path.abspath(args.output_path)
    print("output_path: {}".format(output_path))

    urls = get_video_urls(args.urls_file)
    print("video urls count: {}".format(len(urls)))
    # urls = list(set(urls))
    # print("set video urls count: {}".format(len(urls)))
    # return

    for idx, url in enumerate(urls):
        try:
            tic = time.time()
            print("download: {}".format(url))
            filename_prefix = str(idx).zfill(4) + '_'
            download_youtube_video(url, output_path, filename_prefix)
            print("download complete. {:.2f} sec\n".format(time.time()-tic))
        except Exception as e:
            print(e)
            print("skip downloading this video\n")


def get_video_urls(urls_file):
    with open(urls_file, 'r', encoding='utf-8') as fp:
        urls = fp.readlines()
    urls = [url.replace("\n", "") for url in urls]
    return urls


def download_youtube_video(url, output_path, filename_prefix):
    yt = YouTube(url=url)
    print("title: {}".format(yt.title))
    print("list: {}".format(yt.streams.all))
    yt.streams.filter(adaptive=True, file_extension='mp4').first().download(output_path, filename_prefix=filename_prefix, skip_existing=True)


def parse_arguments(argv):
    parser = argparse.ArgumentParser(description='download_video')
    parser.add_argument('--urls_file')
    parser.add_argument('--output_path', default='download', help='analysis target video file')
    return parser.parse_args(argv)


if __name__ == '__main__':
    # sys.argv = ['download_video.py',
    #             '--urls_file', r'data\youtube_video_urls.txt',
    #             '--output_path', r'data\video']
    args = parse_arguments(sys.argv[1:])
    tic = time.time()
    print("start main")
    main(args)
    print("end main, processing time: {:.2f} sec".format(time.time()-tic))
