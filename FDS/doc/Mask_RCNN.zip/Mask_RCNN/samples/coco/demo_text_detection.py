# ==============================================================================
# @file demo.py
#   - description
#
# Copyright ⓒ DT융합연구소 CJ OliveNetworks, All rights reserved.
# 
# version  
# history 
#  - first version  2020-02-20
# ==============================================================================
import sys, os, cv2, time
import random
import math
import numpy as np
import skimage.io
from imutils.object_detection import non_max_suppression
from skimage.transform import rescale, resize, downscale_local_mean

# from imutils.object_detection import non_max_suppression
import matplotlib.pyplot as plt
from PIL import Image as pImg, ImageDraw, ImageFont
# Root directory of the project
ROOT_DIR = os.path.abspath("./")
GREEN = (0, 255, 0)
BLUE = (255, 0, 0)
RED = (0, 0, 255)
# Import Mask RCNN
sys.path.append(ROOT_DIR)  # To find local version of the library
print(" >>>>>>>>>>>>>>>>>>>>>>>> ROOT_DIR : {}".format(ROOT_DIR))
from mrcnn import utils
import mrcnn.model as modellib
from mrcnn import visualize
from samples.coco import coco
# from tensorflow.compat.v1 import ConfigProto
# from tensorflow.compat.v1 import InteractiveSession

class InferenceConfig(coco.CocoConfig):
    # Set batch size to 1 since we'll be running inference on
    # one image at a time. Batch size = GPU_COUNT * IMAGES_PER_GPU
    NUM_CLASSES = 1 + 1
    NAME = "youtube"
    IMAGES_PER_GPU = 1
    IMAGE_MIN_DIM = 1 * 64
    IMAGE_MAX_DIM = 10 * 64
    # STEPS_PER_EPOCH = 2405
    # VALIDATION_STEPS = 266
    GPU_COUNT = 1

def detection_make_img(file_path_name, out_file_path_name, boxes, class_ids, class_names, scores):
    N = boxes.shape[0]
    colors = visualize.random_colors(N)
    img = cv2.imread(file_path_name)
    rect_img = img.copy()

    print(">>>>>>>>>>>>>>>>>>>>>>>>>>>> boxes >>>>>>>>>> : {}".format(len(boxes)))
    # boxes = non_max_suppression(np.array(boxes), probs=None, overlapThresh=0.65)  # 0.65
    # for (x1, y1, x2, y2) in boxes:
    #     cv2.rectangle(rect_img, (x1, y1), (x2, y2), (0, 0, 255), 2)
    # print(">>>>>>>>>>>>>>>>>>>>>>>>>>>> boxes >>>>>>>>>. : {}".format(len(boxes)))
    # Generate random colors

    print(">>>>>>>>>>>>>>>>>>>>>>>>>>>> boxes >>>>>>>>>. : {}".format(len(boxes)))

    rects_shelf_life = []
    for i in range(N):
        color = colors[i]
        y1, x1, y2, x2 = boxes[i]

        w = x2 - x1
        h = y2 - y1

        class_id = class_ids[i]
        score = scores[i] if scores is not None else None
        label = class_names[class_id]

        print("###. boxes[{}] , xy : {} , label : {}, score : {}".format(i, boxes[i], label, score))
        if label == 'shelf_life':
            cv2.rectangle(rect_img, (x1, y1), (x1 + w, y1 +h), RED, 2)
            rects_shelf_life.append((x1, y1, x1+w, y1+h))
        else:
            cv2.rectangle(rect_img, (x1, y1), (x1 + w, y1 +h), GREEN, 2)

        cv2.imwrite(out_file_path_name, rect_img)

    return rects_shelf_life







if __name__ == '__main__':
    # Directory to save logs and trained model
    MODEL_DIR = os.path.join(ROOT_DIR, "logs")

    # Directory of images to run detection on
    # IMAGE_DIR = os.path.join(ROOT_DIR, "images", "shelf_life", 'test')
    IMAGE_DIR = r"D:\jongchan\source\pycharm\youtube\data\coco_format\val2017\JPEGImages"
    # IMAGE_RESCALE_DIR = os.path.join(ROOT_DIR, "images", "shelf_life", 'high', 'rescale')
    COCO_MODEL_PATH = r'D:\jongchan\source\git\Mask_RCNN\logs\youtube20200428T1733\mask_rcnn_youtube_0160.h5'

    OUT_IMAGE_DIR = r'D:\jongchan\source\git\Mask_RCNN\result\youtube'
    OUT_NMX_IMAGE_DIR = r'D:\jongchan\source\git\Mask_RCNN\result\youtube_nmx'
    # OUT_NMX_SUB_IMAGE_DIR = 'C:/app/ocr/pycharm_workspace/projects/mask-rcnn-text-detection/images/result/shelf_life/real_high_416_01_nmx/sub'

    # if not os.path.exists(IMAGE_RESCALE_DIR):
    #     os.makedirs(IMAGE_RESCALE_DIR)
    if not os.path.exists(OUT_IMAGE_DIR):
        os.makedirs(OUT_IMAGE_DIR)
    if not os.path.exists(OUT_NMX_IMAGE_DIR):
        os.makedirs(OUT_NMX_IMAGE_DIR)
    # if not os.path.exists(OUT_NMX_SUB_IMAGE_DIR):
    #     os.makedirs(OUT_NMX_SUB_IMAGE_DIR)
    print("###################### IMAGE_DIR : {} ".format(IMAGE_DIR))
    time_init = time.time()
    config = InferenceConfig()

    # Create model object in inference mode.
    model = modellib.MaskRCNN(mode="inference", model_dir=MODEL_DIR, config=config)

    # tfconfig = ConfigProto()
    # tfconfig.gpu_options.allow_growth = True
    # session = InteractiveSession(config=tfconfig)


    print("###################### COCO_MODEL_PATH : {} ".format(COCO_MODEL_PATH))
    # Load weights trained on MS-COCO
    model.load_weights(COCO_MODEL_PATH, by_name=True)

    # COCO Class names
    # Index of the class in the list is its ID. For example, to get ID of
    # class_names = ['BG', 'shelf_life', 'text']
    class_names = ['BB','shelf_life', 'text']
    # Load a random image from the images folder
    time_init_end = time.time() - time_init
    time_detection = time.time()
    count = 0
    for path, dirs, files in os.walk(IMAGE_DIR):
        # print("path s: ", path, " , dirs : ", dirs, ", txtfiles : ", files)

        for file_name in files:
            # print('path : {}'.format(path))
            img_file_path_name = os.path.join(IMAGE_DIR, file_name)

            # image_rescale= cv2.imread(img_file_path_name)
            # image_rescaled = cv2.resize(image_rescale, dsize=(0, 0), fx=1.0, fy=1.0, interpolation=cv2.INTER_LINEAR)
            # rescaled_name = file_name.replace(".JPG", "_rescale.JPG")
            # rescaled_path_name = os.path.join(IMAGE_RESCALE_DIR, rescaled_name)
            # cv2.imwrite(rescaled_path_name, image_rescaled)

            # image_rescale = skimage.io.imread(img_file_path_name)
            # image_rescaled = rescale(image_rescale, 0.5, anti_aliasing=False)
            # rescaled_name = file_name.replace(".png", "_rescale.png")
            # rescaled_path_name = os.path.join(IMAGE_RESCALE_DIR, rescaled_name)
            # skimage.io.imsave(rescaled_path_name, image_rescaled)

            image = skimage.io.imread(img_file_path_name)

            # Run detection
            results = model.detect([image], verbose=1)
            r = results[0]
            print("rois len : {}, masks len : {}, class_ids len : {}, results len : {}, results[0] : {}".format(len(r['rois']), len(r['masks']), len(r['class_ids']) , len(results), len(results[0])))
            out_file_path_name = os.path.join(OUT_IMAGE_DIR, file_name)
            rects_shelf_life = detection_make_img(img_file_path_name, out_file_path_name, r['rois'], r['class_ids'],
                            class_names, r['scores'])

            boxes = non_max_suppression(np.array(rects_shelf_life), probs=None, overlapThresh=0.65)  # 0.65

            nmx_img = cv2.imread(img_file_path_name)
            nmx_rect_img_copy = nmx_img.copy()
            nmx_crop_img_copy = nmx_img.copy()
            nmx_len = len(boxes)
            out_file_nmx_path_name = os.path.join(OUT_NMX_IMAGE_DIR, file_name)
            # out_file_sub_path_name = os.path.join(OUT_NMX_SUB_IMAGE_DIR, file_name)
            for i in range(nmx_len):
                (widthA, heightA, widthB, heightB) = boxes[i]
                cv2.rectangle(nmx_rect_img_copy, (widthA, heightA), (widthB, heightB), RED,
                              2)
                # crop_img = nmx_crop_img_copy[heightA: heightB, widthA: widthB]
                # cv2.imwrite(out_file_sub_path_name.replace(".JPG", "_"+str(i)+".JPG"), crop_img)
            cv2.imwrite(out_file_nmx_path_name, nmx_rect_img_copy)

            count = count + 1

    print("### time_init_end : {}, time_detection : {}, time_detection per : {}".format(time_init_end, time.time() - time_detection, (time.time() - time_detection)/count))

